package com.hexaware.entity;

public class DatabaseContext {

}
