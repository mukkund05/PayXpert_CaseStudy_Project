package com.hexaware.dao;

import com.hexaware.entity.Tax;
import com.hexaware.exception.DatabaseConnectionException;
import com.hexaware.exception.TaxCalculationException;
import com.hexaware.util.DBConnUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TaxService implements ITaxService {
    private Connection conn;

    public TaxService() throws DatabaseConnectionException {
        this.conn = DBConnUtil.getConnection("db.properties");
    }

    @Override
    public double calculateTax(int employeeID, int taxYear) throws TaxCalculationException {
        double taxableIncome = 50000.0; // Placeholder for actual income logic
        double taxRate = 0.2; // Placeholder tax rate (20%)
        double taxAmount = taxableIncome * taxRate;

        String sql = "INSERT INTO Tax (EmployeeID, TaxYear, TaxableIncome, TaxAmount) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employeeID);
            pstmt.setInt(2, taxYear);
            pstmt.setDouble(3, taxableIncome);
            pstmt.setDouble(4, taxAmount);
            pstmt.executeUpdate();
            return taxAmount;
        } catch (SQLException e) {
            throw new TaxCalculationException("Failed to calculate tax: " + e.getMessage());
        }
    }

    @Override
    public Tax getTaxById(int taxID) throws TaxCalculationException {
        String sql = "SELECT * FROM Tax WHERE TaxID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, taxID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToTax(rs);
            } else {
                throw new TaxCalculationException("Tax with ID " + taxID + " not found");
            }
        } catch (SQLException e) {
            throw new TaxCalculationException("Database error: " + e.getMessage());
        }
    }

    @Override
    public List<Tax> getTaxesForEmployee(int employeeID) throws TaxCalculationException {
        List<Tax> taxes = new ArrayList<>();
        String sql = "SELECT * FROM Tax WHERE EmployeeID = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, employeeID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                taxes.add(mapResultSetToTax(rs));
            }
            return taxes;
        } catch (SQLException e) {
            throw new TaxCalculationException("Database error: " + e.getMessage());
        }
    }

    @Override
    public List<Tax> getTaxesForYear(int taxYear) throws TaxCalculationException {
        List<Tax> taxes = new ArrayList<>();
        String sql = "SELECT * FROM Tax WHERE TaxYear = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, taxYear);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                taxes.add(mapResultSetToTax(rs));
            }
            return taxes;
        } catch (SQLException e) {
            throw new TaxCalculationException("Database error: " + e.getMessage());
        }
    }

    private Tax mapResultSetToTax(ResultSet rs) throws SQLException {
        Tax tax = new Tax();
        tax.setTaxID(rs.getInt("TaxID"));
        tax.setEmployeeID(rs.getInt("EmployeeID"));
        tax.setTaxYear(rs.getInt("TaxYear"));
        tax.setTaxableIncome(rs.getDouble("TaxableIncome"));
        tax.setTaxAmount(rs.getDouble("TaxAmount"));
        return tax;
    }
}