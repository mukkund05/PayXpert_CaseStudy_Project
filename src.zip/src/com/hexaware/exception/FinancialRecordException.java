package com.hexaware.exception;

public class FinancialRecordException extends Exception {
    public FinancialRecordException(String message) {
        super(message);
    }
}