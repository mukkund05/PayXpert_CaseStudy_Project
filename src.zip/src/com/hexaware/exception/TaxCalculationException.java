package com.hexaware.exception;

public class TaxCalculationException extends Exception {
    public TaxCalculationException(String message) {
        super(message);
    }
}