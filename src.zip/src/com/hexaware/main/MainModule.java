package com.hexaware.main;
import java.sql.*;

import com.hexaware.util.DBConnUtil;
import com.hexaware.util.DBPropertyUtil;


public class MainModule {
	
	public static void main(String[] args) {
		
		String propertyFileName = "E:\\CASE STUDY\\PayXpert\\PayXpert\\src\\util\\db.properties";
		
		
		String connectionString = DBPropertyUtil.getConnectionString(propertyFileName);
		
		try {
			
			Connection conn = DBConnUtil.getConnection(connectionString);
			
			
			System.out.println("Connected to the database!");
			
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		
	}
	
	

}
